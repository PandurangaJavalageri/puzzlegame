﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace NumberPuzzleApplication
{
    public class PuzzleControl
    {
        #region Fields of the class
        Random rnd= new Random();
        #endregion

        /// <summary>
        /// Method to generate a random number
        /// </summary>
        /// <returns></returns>
        private int GetRandomNumber()
        {   
            return rnd.Next(17);
        }

        /// <summary>
        /// Method to change the value of the button when clicked
        /// </summary>
        /// <param name="emptyButton"></param>
        /// <param name="clicked"></param>
        private void SwapButton(Button emptyButton, Button clicked)
        {
            emptyButton.Text = clicked.Text;
            clicked.Text = "";
        }
        
        /// <summary>
        /// Method to get an array of integers for the buttons on the grid
        /// </summary>
        /// <param name="buttons"></param>
        /// <returns></returns>
        private int[] GetIntegerArrayOfButtonIds(Button[] buttons)
        {
            int[] buttonIds = new int[16];
            int id;
            for (int i = 0; i < 16; ++i)
            {
                if (int.TryParse(buttons[i].Text, out id))
                    buttonIds[i] = id;
                else
                    buttonIds[i] = 16;
            }
            return buttonIds;
        }

        
        //----------------------Public Methods to be filled by the participant------------


        /// <summary>
        /// Method to get random numbers to be displayed on the grid
        /// </summary>
        /// <returns></returns>
        public int[] GetRandomNumbersForGrid()
        {
            int[] arr = new int[16];
            for(int i = 0;i<16;i++)
            {
                arr[i] = i + 1;
            }
            for(int i = 0;i<16;i++)
            {
                int ran= rnd.Next(16);
                int temp = arr[i];
                arr[i] = arr[ran];
                arr[ran] = temp;
            }


            //Logic to be filled by the participant

            return arr;
        }

        /// <summary>
        /// Method to swap the buttons when a number is clicked on the grid
        /// </summary>
        /// <param name="emptyCellId"></param>
        /// <param name="buttonClicked"></param>
        /// <param name="buttons"></param>
        /// <returns></returns>
        public int HandleButtonClicked(int emptyCellId, Button buttonClicked, Button[] buttons)
        {

            //Logic to be filled by the participant
            int i= 0;
            for( i = 0;i<buttons.Length;i++)
            {
                if (buttons[i] == buttonClicked)
                    break;
            }
            if (i == 3 || i == 7 || i == 11)
            {
                if (i - 4 >= 0 && i - 4 == emptyCellId)
                {
                    SwapButton(buttons[emptyCellId], buttonClicked);
                    return i;
                }
                else if (i - 1 >= 0 && i - 1 == emptyCellId)
                {
                    SwapButton(buttons[emptyCellId], buttonClicked);
                    return i;
                }
                else if (i + 4 <= 15 && i + 4 == emptyCellId)
                {
                    SwapButton(buttons[emptyCellId], buttonClicked);
                    return i;
                }
            }
            else if (i==4||i==8||i==12)
            {
                if (i - 4 >= 0 && i - 4 == emptyCellId)
                {
                    SwapButton(buttons[emptyCellId], buttonClicked);
                    return i;
                }
                else if (i + 1 >= 0 && i + 1 == emptyCellId)
                {
                    SwapButton(buttons[emptyCellId], buttonClicked);
                    return i;
                }
                else if (i + 4 <= 15 && i + 4 == emptyCellId)
                {
                    SwapButton(buttons[emptyCellId], buttonClicked);
                    return i;
                }
            }
            else
            {
                if (i - 4 >= 0 && i - 4 == emptyCellId)
                {
                    SwapButton(buttons[emptyCellId], buttonClicked);
                    return i;
                }
                else if (i - 1 >= 0 && i - 1 == emptyCellId)
                {
                    SwapButton(buttons[emptyCellId], buttonClicked);
                    return i;
                }
                else if (i + 4 <= 15 && i + 4 == emptyCellId)
                {
                    SwapButton(buttons[emptyCellId], buttonClicked);
                    return i;
                }
                else if (i + 1 >= 0 && i + 1 == emptyCellId)
                {
                    SwapButton(buttons[emptyCellId], buttonClicked);
                    return i;
                }
            }




                return emptyCellId;
        }

        /// <summary>
        /// Method to check for a winner of the game
        /// </summary>
        /// <param name="buttons"></param>
        /// <param name="buttons"></param>
        /// <returns></returns>
        public bool CheckForWinner(Button[] buttons)
        {
            bool winner = true;
            int[] arr = GetIntegerArrayOfButtonIds(buttons);
            for(int i = 0; i <arr.Length; i++)
            {
                if (i+1< arr.Length && arr[i] >= arr[i + 1])
                {
                    return false;
                }
            }


            return winner;
        }


    }
}
